
<h1>Medium App clone</h1>




https://user-images.githubusercontent.com/75681588/232289509-e2093b3a-f959-44d7-abca-18bf1a116e11.mp4



<p>
    <img src="images/signin.png" width="270">
    <img src="images/signup.png" width="270">
  <img src="images/mainscreenshimmer.png" width="270" >
  <img src="images/homescreen.png" width="270">
  <img src="images/homescreen1.png" width="270">
  <img src="images/opennews.png" width="270">
  <img src="images/searchednews.png" width="270">
  <img src="images/searchnews.png" width="270">
  <img src="images/settingscreen.png" width="270">
  <img src="images/drawer.png" width="270">
  <img src="images/profilescreen.png" width="270">
  <img src="images/editprofile.png" width="270">
 
  </p>
