class ArtUtil {
  static const hide = "Hide";
  static const String share = "Share";

  static const List<String> menuItem = [hide, share];
}
