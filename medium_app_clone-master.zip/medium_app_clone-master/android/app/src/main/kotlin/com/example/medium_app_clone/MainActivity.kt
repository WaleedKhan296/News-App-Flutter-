package com.example.medium_app_clone

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
